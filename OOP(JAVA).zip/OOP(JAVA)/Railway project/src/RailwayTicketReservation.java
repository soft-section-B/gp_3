import java.io.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.io.Serial;

class Reservation implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;
    int id;
    String name;
    LocalDateTime reservationTime;
    String tripType;
    String trainNumber;
    String route;
    int seatNumber;
    double price;
    boolean feePaid;

    Reservation(int id, String name, LocalDateTime reservationTime, String tripType,
                String trainNumber, String route, int seatNumber, double price) {
        this.id = id;
        this.name = name;
        this.reservationTime = reservationTime;
        this.tripType = tripType;
        this.trainNumber = trainNumber;
        this.route = route;
        this.seatNumber = seatNumber;
        this.price = price;
        this.feePaid = false;
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Name: " + name + ", Time: " + reservationTime +
                ", Trip Type: " + tripType + ", Train No: " + trainNumber + ", Route: " + route +
                ", Seat: " + seatNumber + ", Price: ETbirr" + price + ", Fee Paid: " + feePaid;
    }
}

public class RailwayTicketReservation {
    private static final String FILE_NAME = "reservations.txt";
    private static final String PASS_FILE = "admin_pass.txt";
    private static final String PRICE_FILE = "price.txt";
    private static final Scanner scanner = new Scanner(System.in);
    private static final Map<Integer, Reservation> reservations = new HashMap<>();
    private static int idCounter = 1;
    private static String adminPassword = "admin123";
    private static double basePrice = 500.0;

    private static final Map<String, String> trains = new HashMap<>(Map.of(
            "T1", "Addis Ababa - Dire Dawa",
            "T2", "Addis Ababa - Bahir Dar",
            "T3", "Addis Ababa - Dessie"
    ));

    private static final Map<String, Integer> trainCapacity = new HashMap<>(Map.of(
            "T1", 10,
            "T2", 10,
            "T3", 10
    ));

    public static void main(String[] args) {
        loadReservations();
        loadAdminPassword();
        loadBasePrice();
        while (true) {
            autoCancel();
            showMenu();
            int choice = getChoice();
            switch (choice) {
                case 1 -> reserveTicket();
                case 2 -> cancelReservation();
                case 3 -> updateReservation();
                case 4 -> payFee();
                case 5 -> showReservations();
                case 6 -> adminMode();
                case 7 -> {
                    saveReservations();
                    saveAdminPassword();
                    saveBasePrice();
                    System.out.println("Exiting... Goodbye!");
                    System.exit(0);
                }
                default -> System.out.println("Invalid option. Try again.");
            }
        }
    }

    private static void showMenu() {
        System.out.println("\n=== Railway Ticket Reservation System ===");
        System.out.println("1. Reserve Ticket");
        System.out.println("2. Cancel Reservation");
        System.out.println("3. Update Reservation Time");
        System.out.println("4. Pay Fee");
        System.out.println("5. Show Reservations");
        System.out.println("6. Admin Mode");
        System.out.println("7. Exit");
        System.out.print("Choose option: ");
    }

    private static int getChoice() {
        while (!scanner.hasNextInt()) {
            System.out.print("Please enter a valid number: ");
            scanner.next();
        }
        return scanner.nextInt();
    }

    private static void reserveTicket() {
        scanner.nextLine();
        String[] trainInfo = chooseTrain();
        String trainNumber = trainInfo[0];

        if (countTrainReservations(trainNumber) >= trainCapacity.get(trainNumber)) {
            System.out.println("Cannot reserve: Train is full.");
            return;
        }

        System.out.print("Enter your name: ");
        String name = scanner.nextLine();
        LocalDateTime time = readReservationTime();

        Duration duration = Duration.between(LocalDateTime.now(), time);
        if (duration.toHours() < 3) {
            System.out.println("Cannot reserve ticket: Less than 3 hours to departure.");
            return;
        }

        String tripType = readTripType();
        int seatNumber = chooseSeat(trainNumber);
        if (seatNumber == -1) {
            System.out.println("All seats are taken.");
            return;
        }

        double price = calculatePrice(tripType);
        System.out.println("Total price: ETbirr" + price);
        System.out.print("Proceed to payment? (yes/no): ");
        String pay = scanner.nextLine();
        boolean feePaid = pay.equalsIgnoreCase("yes");

        Reservation res = new Reservation(idCounter, name, time, tripType, trainNumber,
                trainInfo[1], seatNumber, price);
        res.feePaid = feePaid;
        reservations.put(idCounter, res);

        System.out.println("Reservation successful! Your ID is: " + idCounter);
        if (!feePaid) {
            System.out.println("⚠ Please pay before 3 hours of departure.");
        }
        idCounter++;
        saveReservations();
    }

    private static int chooseSeat(String trainNumber) {
        int capacity = trainCapacity.get(trainNumber);
        Set<Integer> takenSeats = new HashSet<>();
        for (Reservation r : reservations.values()) {
            if (r.trainNumber.equals(trainNumber)) {
                takenSeats.add(r.seatNumber);
            }
        }
        List<Integer> availableSeats = new ArrayList<>();
        for (int i = 1; i <= capacity; i++) {
            if (!takenSeats.contains(i)) {
                availableSeats.add(i);
            }
        }
        if (availableSeats.isEmpty()) {
            return -1;
        }
        System.out.println("Available seats: " + availableSeats);
        while (true) {
            System.out.print("Choose seat number: ");
            int seat = scanner.nextInt();
            scanner.nextLine();
            if (availableSeats.contains(seat)) {
                return seat;
            } else {
                System.out.println("Invalid seat number. Try again.");
            }
        }
    }

    private static int countTrainReservations(String trainNumber) {
        int count = 0;
        for (Reservation r : reservations.values()) {
            if (r.trainNumber.equals(trainNumber)) {
                count++;
            }
        }
        return count;
    }

    private static void cancelReservation() {
        System.out.print("Enter reservation ID to cancel: ");
        int id = scanner.nextInt();
        if (reservations.containsKey(id)) {
            reservations.remove(id);
            System.out.println("Reservation cancelled.");
            saveReservations();
        } else {
            System.out.println("Reservation not found.");
        }
    }

    private static void updateReservation() {
        System.out.print("Enter reservation ID to update time: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        if (reservations.containsKey(id)) {
            LocalDateTime newTime = readReservationTime();
            Duration duration = Duration.between(LocalDateTime.now(), newTime);
            if (duration.toHours() < 3) {
                System.out.println("Cannot update: Less than 3 hours to departure.");
                return;
            }
            Reservation res = reservations.get(id);
            res.reservationTime = newTime;
            res.feePaid = false;
            System.out.println("Time updated. Please pay again.");
            saveReservations();
        } else {
            System.out.println("Reservation not found.");
        }
    }

    private static void payFee() {
        System.out.print("Enter reservation ID to pay fee: ");
        int id = scanner.nextInt();
        if (reservations.containsKey(id)) {
            reservations.get(id).feePaid = true;
            System.out.println("Payment successful.");
            saveReservations();
        } else {
            System.out.println("Reservation not found.");
        }
    }

    private static void showReservations() {
        if (reservations.isEmpty()) {
            System.out.println("No reservations found.");
        } else {
            reservations.values().forEach(System.out::println);
        }
    }

    private static void adminMode() {
        System.out.print("Enter admin password: ");
        scanner.nextLine();
        String pass = scanner.nextLine();
        if (!pass.equals(adminPassword)) {
            System.out.println("Wrong password.");
            return;
        }
        while (true) {
            System.out.println("\n=== Admin Mode ===");
            System.out.println("1. View Reservations");
            System.out.println("2. Delete Reservation");
            System.out.println("3. Add Train");
            System.out.println("4. Remove Train");
            System.out.println("5. Set Train Capacity");
            System.out.println("6. Change Admin Password");
            System.out.println("7. Set Ticket Base Price");
            System.out.println("8. Exit Admin Mode");
            System.out.print("Choose option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();
            switch (choice) {
                case 1 -> showReservations();
                case 2 -> {
                    System.out.print("Enter reservation ID to delete: ");
                    int id = scanner.nextInt();
                    scanner.nextLine();
                    if (reservations.remove(id) != null) {
                        System.out.println("Deleted.");
                        saveReservations();
                    } else {
                        System.out.println("Not found.");
                    }
                }
                case 3 -> {
                    System.out.print("Enter train number: ");
                    String tNum = scanner.nextLine();
                    System.out.print("Enter route: ");
                    String route = scanner.nextLine();
                    trains.put(tNum, route);
                    trainCapacity.put(tNum, 10);
                    System.out.println("Train added.");
                }
                case 4 -> {
                    System.out.print("Enter train number to remove: ");
                    String tNum = scanner.nextLine();
                    trains.remove(tNum);
                    trainCapacity.remove(tNum);
                    reservations.values().removeIf(r -> r.trainNumber.equals(tNum));
                    System.out.println("Train and related reservations removed.");
                    saveReservations();
                }
                case 5 -> {
                    System.out.print("Enter train number: ");
                    String tNum = scanner.nextLine();
                    System.out.print("Enter new capacity: ");
                    int cap = scanner.nextInt();
                    scanner.nextLine();
                    trainCapacity.put(tNum, cap);
                    System.out.println("Capacity updated.");
                }
                case 6 -> {
                    System.out.print("Enter new admin password: ");
                    adminPassword = scanner.nextLine();
                    saveAdminPassword();
                    System.out.println("Admin password changed.");
                }
                case 7 -> {
                    System.out.print("Enter new base price: ");
                    basePrice = scanner.nextDouble();
                    scanner.nextLine();
                    saveBasePrice();
                    System.out.println("Base price updated to $" + basePrice);
                }
                case 8 -> {
                    System.out.println("Exiting Admin Mode.");
                    return;
                }
                default -> System.out.println("Invalid option.");
            }
        }
    }

    private static LocalDateTime readReservationTime() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        while (true) {
            System.out.print("Enter reservation time (yyyy-MM-dd HH:mm): ");
            String input = scanner.nextLine();
            try {
                return LocalDateTime.parse(input, formatter);
            } catch (Exception e) {
                System.out.println("Invalid format. Try again.");
            }
        }
    }

    private static String readTripType() {
        while (true) {
            System.out.print("Trip type (One-way / Round-trip): ");
            String input = scanner.nextLine().toLowerCase();
            if (input.equals("one-way") || input.equals("round-trip")) {
                return input;
            } else {
                System.out.println("Invalid input. Please enter 'One-way' or 'Round-trip'.");
            }
        }
    }

    private static String[] chooseTrain() {
        System.out.println("Available trains:");
        trains.forEach((k, v) -> System.out.println(k + ": " + v));
        while (true) {
            System.out.print("Enter train number: ");
            String trainNumber = scanner.nextLine().toUpperCase();
            if (trains.containsKey(trainNumber)) {
                return new String[]{trainNumber, trains.get(trainNumber)};
            } else {
                System.out.println("Invalid train number. Try again.");
            }
        }
    }

    private static double calculatePrice(String tripType) {
        return tripType.equalsIgnoreCase("round-trip") ? basePrice * 1.8 : basePrice;
    }

    private static void autoCancel() {
        LocalDateTime now = LocalDateTime.now();
        List<Integer> toCancel = new ArrayList<>();
        for (Reservation res : reservations.values()) {
            Duration duration = Duration.between(now, res.reservationTime);
            if (duration.toHours() <= 3 && !res.feePaid) {
                toCancel.add(res.id);
            }
        }
        for (int id : toCancel) {
            reservations.remove(id);
            System.out.println("Reservation ID " + id + " auto-cancelled (fee not paid 3 hours before).");
        }
        if (!toCancel.isEmpty()) {
            saveReservations();
        }
    }

    private static void saveReservations() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
            oos.writeObject(reservations);
            oos.writeObject(idCounter);
        } catch (IOException e) {
            System.out.println("Error saving reservations: " + e.getMessage());
        }
    }
    @SuppressWarnings("unchecked")
    private static void loadReservations() {
        File file = new File(FILE_NAME);
        if (!file.exists()) {
            return;
        }
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FILE_NAME))) {
            Map<Integer, Reservation> loaded = (Map<Integer, Reservation>) ois.readObject();
            reservations.putAll(loaded);
            idCounter = (Integer) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error loading reservations: " + e.getMessage());
        }
    }

    private static void saveAdminPassword() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(PASS_FILE))) {
            writer.write(adminPassword);
        } catch (IOException e) {
            System.out.println("Error saving admin password: " + e.getMessage());
        }
    }

    private static void loadAdminPassword() {
        File file = new File(PASS_FILE);
        if (!file.exists()) {
            return;
        }
        try (BufferedReader reader = new BufferedReader(new FileReader(PASS_FILE))) {
            adminPassword = reader.readLine();
        } catch (IOException e) {
            System.out.println("Error loading admin password: " + e.getMessage());
        }
    }

    private static void saveBasePrice() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(PRICE_FILE))) {
            writer.write(String.valueOf(basePrice));
        } catch (IOException e) {
            System.out.println("Error saving base price: " + e.getMessage());
        }
    }

    private static void loadBasePrice() {
        File file = new File(PRICE_FILE);
        if (!file.exists()) {
            return;
        }
        try (BufferedReader reader = new BufferedReader(new FileReader(PRICE_FILE))) {
            basePrice = Double.parseDouble(reader.readLine());
        } catch (IOException | NumberFormatException e) {
            System.out.println("Error loading base price: " + e.getMessage());
        }
    }
}
