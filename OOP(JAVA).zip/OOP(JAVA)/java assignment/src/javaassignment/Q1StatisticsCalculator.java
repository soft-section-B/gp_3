package javaassignment;
import java.util.Scanner;

public class Q1StatisticsCalculator {
    public static void main(String[] args) {
        StatCalc calc = new StatCalc();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter numbers (0 to stop):");
        while (true) {
            double num = scanner.nextDouble();
            if (num == 0) break;
            calc.enter(num);
        }

        System.out.println("\nResults:");
        System.out.println("Count: " + calc.getCount());
        System.out.println("Sum: " + calc.getSum());
        System.out.println("Average: " + calc.getMean());
        System.out.println("Max: " + calc.getMax());
        System.out.println("Min: " + calc.getMin());
        System.out.println("Standard Deviation: " + calc.getStandardDeviation());
    }
}