package javaassignment;
import java.util.Scanner;

public class Q3FactorComparator {
    public static int sameNumberOfFactors(int n1, int n2) {
        if (n1 < 0 || n2 < 0) return -1;
        if (n1 == n2) return 1;
        return (countFactors(n1) == countFactors(n2)) ? 1 : 0;
    }

    private static int countFactors(int num) {
        if (num == 0) return 0;
        int count = 1;
        for (int i = 2; i <= num; i++) {
            if (num % i == 0) count++;
        }
        return count;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("=== Factor Comparison Program ===");
        System.out.println("Enter two numbers separated by space (e.g., '6 21')");
        System.out.println("Type 'exit' to quit the program\n");

        while (true) {
            System.out.print("Your input: ");
            String input = scanner.nextLine().trim();

            if (input.equalsIgnoreCase("exit")) {
                System.out.println("Program ended. Goodbye!");
                break;
            }

            try {
                String[] parts = input.split(" ");
                if (parts.length != 2) {
                    System.out.println("Error: Please enter exactly 2 numbers separated by space!");
                    continue;
                }

                int n1 = Integer.parseInt(parts[0]);
                int n2 = Integer.parseInt(parts[1]);
                int result = sameNumberOfFactors(n1, n2);

                System.out.println("Result: " + interpretResult(result));
            } catch (NumberFormatException e) {
                System.out.println("Invalid input! Please enter numbers only (e.g., '6 21')");
            }
            System.out.println();  // Add empty line for readability
        }
        scanner.close();
    }

    private static String interpretResult(int result) {
        return switch (result) {
            case -1 -> "-1";
            case 1 -> "1";
            case 0 -> "0";
            default -> "Unexpected result";
        };
    }
}