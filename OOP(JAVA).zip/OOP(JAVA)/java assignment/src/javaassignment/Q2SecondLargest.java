package javaassignment;
import java.util.Scanner;

public class Q2SecondLargest {
    public static int f(int[] a) {
        if (a == null || a.length < 2) return -1;

        int largest = -1;
        int secondLargest = -1;

        for (int num : a) {
            if (num > largest) {
                secondLargest = largest;
                largest = num;
            } else if (num > secondLargest && num < largest) {
                secondLargest = num;
            }
        }
        return secondLargest;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter numbers separated by spaces (e.g., '1 2 3'). Type 'exit' to quit.");

        while (true) {
            System.out.print("\nInput numbers: ");
            String input = scanner.nextLine().trim();

            if (input.equalsIgnoreCase("exit")) {
                System.out.println("Exiting program. Goodbye!");
                break;
            }

            try {
                String[] parts = input.split(" ");
                int[] numbers = new int[parts.length];

                for (int i = 0; i < parts.length; i++) {
                    numbers[i] = Integer.parseInt(parts[i]);
                }

                int result = f(numbers);
                System.out.println("Second largest: " + (result != -1 ? result : "None (all numbers equal)"));
            } catch (NumberFormatException e) {
                System.out.println("Invalid input! Please enter numbers only (e.g., '4 1 7').");
            }
        }
        scanner.close();
    }
}