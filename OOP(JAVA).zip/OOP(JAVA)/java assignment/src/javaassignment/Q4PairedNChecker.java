package javaassignment;
import java.util.Scanner;

public class Q4PairedNChecker {
    public static int isPairedN(int[] a, int n) {
        if (a.length < 2 || n < 0 || n > (a.length-1)*2) return 0;

        for (int i = 0; i < a.length; i++) {
            for (int j = i+1; j < a.length; j++) {
                if (a[i] + a[j] == n && i + j == n) {
                    return 1;
                }
            }
        }
        return 0;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("=== Paired-N Checker (Type 'exit' to quit) ===");

        while (true) {
            // Array input
            System.out.print("Array: ");
            String arrayInput = scanner.nextLine().trim();
            if (arrayInput.equalsIgnoreCase("exit")) break;

            // N input
            System.out.print("N: ");
            String nInput = scanner.nextLine().trim();
            if (nInput.equalsIgnoreCase("exit")) break;

            try {
                // Parse array
                String[] numStrings = arrayInput.split(" ");
                int[] arr = new int[numStrings.length];
                for (int i = 0; i < numStrings.length; i++) {
                    arr[i] = Integer.parseInt(numStrings[i]);
                }

                // Parse n
                int n = Integer.parseInt(nInput);

                // Calculate and display result
                int result = isPairedN(arr, n);
                System.out.println("Result: " + result +
                        " (" + (result == 1 ? "Paired-N" : "Not Paired-N") + ")\n");

            } catch (NumberFormatException e) {
                System.out.println("Error: Invalid input format. Example:\n" +
                        "Array: 1 4 1 4 5 6\n" +
                        "N: 5\n");
            }
        }
        System.out.println("Program exited.");
        scanner.close();
    }
}