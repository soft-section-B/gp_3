package WORKSHEETOOP;
import java.util.Scanner;

public class Q13ClosestFibonacci {
    public static int closestFibonacci(int n) {
        if (n < 1) {
            return 0;
        }

        int first = 1;
        int second = 1;

        while (second <= n) {
            int next = first + second;
            first = second;
            second = next;
        }

        return first;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input;

        System.out.println("Enter a number to find the closest Fibonacci (type 'exit' to quit):");

        while (true) {
            System.out.print("Enter number: ");
            input = scanner.nextLine();

            if (input.equalsIgnoreCase("exit")) {
                System.out.println("Goodbye!");
                break;
            }

            try {
                int number = Integer.parseInt(input);
                int result = closestFibonacci(number);
                System.out.println("Closest Fibonacci <= " + number + " is: " + result);
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid integer or type 'exit' to quit.");
            }
        }

        scanner.close();
    }
}
