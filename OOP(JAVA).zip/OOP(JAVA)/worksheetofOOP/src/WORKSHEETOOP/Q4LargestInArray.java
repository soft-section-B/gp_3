package WORKSHEETOOP;
import java.util.Scanner;

public class Q4LargestInArray {
    public static int findLargest(int[] array) {
        if (array == null || array.length == 0) {
            throw new IllegalArgumentException("Array must not be empty");
        }

        int largest = array[0];
        for (int num : array) {
            if (num > largest) {
                largest = num;
            }
        }
        return largest;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Largest Number Finder (Type 'exit' to quit)");

        while (true) {
            System.out.print("\nEnter array size or 'exit': ");
            String input = scanner.nextLine();

            if (input.equalsIgnoreCase("exit")) {
                break;
            }

            try {
                int size = Integer.parseInt(input);

                if (size <= 0) {
                    System.out.println("Size must be positive");
                    continue;
                }

                System.out.print("Enter " + size + " integers separated by spaces: ");
                String numbersInput = scanner.nextLine();
                String[] numbersStr = numbersInput.split(" ");

                if (numbersStr.length != size) {
                    System.out.println("You must enter exactly " + size + " numbers");
                    continue;
                }

                int[] numbers = new int[size];
                for (int i = 0; i < size; i++) {
                    numbers[i] = Integer.parseInt(numbersStr[i]);
                }

                System.out.println("Largest number: " + findLargest(numbers));
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter numbers only");
            }
        }

        System.out.println("Program ended. Goodbye!");
    }
}