package WORKSHEETOOP;
public class Q9Counter {
    private int value;  // Private instance variable

    // Constructor initializes counter to 0
    public Q9Counter() {
        value = 0;
    }

    // Increments the counter by 1
    public void increment() {
        value++;
    }

    // Returns the current counter value
    public int getValue() {
        return value;
    }
}