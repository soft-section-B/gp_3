package WORKSHEETOOP;
import java.util.Scanner;

public class Q10CoinTossSimulation {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Coin Toss Simulator (Type 'exit' to quit)");

        while (true) {
            Q9Counter headCount = new Q9Counter();
            Q9Counter tailCount = new Q9Counter();

            System.out.print("\nEnter number of tosses or 'exit': ");
            String input = scanner.nextLine();

            if (input.equalsIgnoreCase("exit")) {
                break;
            }

            try {
                int tosses = Integer.parseInt(input);

                if (tosses <= 0) {
                    System.out.println("Number must be positive");
                    continue;
                }

                System.out.println("Tossing coin " + tosses + " times...");
                for (int i = 0; i < tosses; i++) {
                    if (Math.random() < 0.5) {
                        headCount.increment();
                    } else {
                        tailCount.increment();
                    }
                }

                System.out.println("Results:");
                System.out.println("Heads: " + headCount.getValue());
                System.out.println("Tails: " + tailCount.getValue());
                System.out.printf("Percentage Heads: %.1f%%\n",
                        (headCount.getValue() * 100.0 / tosses));
                System.out.printf("Percentage Tails: %.1f%%\n",
                        (tailCount.getValue() * 100.0 / tosses));

            } catch (NumberFormatException e) {
                System.out.println("Invalid input! Please enter a number.");
            }
        }

        System.out.println("Program ended. Goodbye!");
    }
}