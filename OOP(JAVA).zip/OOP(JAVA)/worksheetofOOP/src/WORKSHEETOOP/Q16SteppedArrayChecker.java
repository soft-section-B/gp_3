package WORKSHEETOOP;
import java.util.Scanner;

public class Q16SteppedArrayChecker {

    public static int isStepped(int[] a) {
        if (a.length == 0) return 0;

        int count = 1;

        for (int i = 1; i < a.length; i++) {
            if (a[i] < a[i - 1]) {
                return 0;
            }

            if (a[i] == a[i - 1]) {
                count++;
            } else {
                if (count < 3) {
                    return 0;
                }
                count = 1;
            }
        }

        if (count < 3) {
            return 0;
        }

        return 1;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input;

        System.out.println("Check if an array is stepped (type 'exit' to quit).");

        while (true) {
            System.out.print("Enter integers separated by spaces: ");
            input = scanner.nextLine();

            if (input.equalsIgnoreCase("exit")) {
                System.out.println("Goodbye!");
                break;
            }

            try {
                String[] parts = input.trim().split("\\s+");
                int[] numbers = new int[parts.length];

                for (int i = 0; i < parts.length; i++) {
                    numbers[i] = Integer.parseInt(parts[i]);
                }

                int result = isStepped(numbers);
                if (result == 1) {
                    System.out.println("1");
                } else {
                    System.out.println("0");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter integers separated by spaces or type 'exit' to quit.");
            }
        }

        scanner.close();
    }
}
