package WORKSHEETOOP;
public class Q11EmployeeDataProcessor {
    static class Employee {
        String lastName;
        String firstName;
        double hourlyWage;
        int yearsWithCompany;
    }

    public static void main(String[] args) {
        Employee[] employeeData = new Employee[100];

        for (int i = 0; i < employeeData.length; i++) {
            employeeData[i] = new Employee();
            employeeData[i].firstName = "Employee" + (i + 1);
            employeeData[i].lastName = "LastName" + (i + 1);
            employeeData[i].hourlyWage = 15.0 + (i % 10);
            employeeData[i].yearsWithCompany = i % 30;
        }

        System.out.println("Employees with 20+ years of service:");
        for (Employee emp : employeeData) {
            if (emp.yearsWithCompany >= 20) {
                System.out.printf("Name: %s %s, Wage: $%.2f%n",
                        emp.firstName, emp.lastName, emp.hourlyWage);
            }
        }
    }
}