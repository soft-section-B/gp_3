package WORKSHEETOOP;
import java.util.Scanner;

public class Q15SumOddEvenDifference {
    public static int f(int[] a) {
        int sumOdd = 0;
        int sumEven = 0;

        for (int num : a) {
            if (num % 2 == 0) {
                sumEven += num;
            } else {
                sumOdd += num;
            }
        }

        return sumOdd - sumEven;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input;

        System.out.println("Calculate X - Y where X = sum of odd numbers and Y = sum of even numbers.");
        System.out.println("Type 'exit' to quit.");

        while (true) {
            System.out.print("Enter integers separated by spaces: ");
            input = scanner.nextLine();

            if (input.equalsIgnoreCase("exit")) {
                System.out.println("Goodbye!");
                break;
            }

            try {
                String[] parts = input.trim().split("\\s+");
                int[] numbers = new int[parts.length];

                for (int i = 0; i < parts.length; i++) {
                    numbers[i] = Integer.parseInt(parts[i]);
                }

                int result = f(numbers);
                System.out.println("Result (X - Y): " + result);
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter integers separated by spaces or type 'exit' to quit.");
            }
        }

        scanner.close();
    }
}
