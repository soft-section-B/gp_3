package WORKSHEETOOP;
import java.util.Scanner;

public class Q12PairOfDice {
    private int die1;
    private int die2;

    public Q12PairOfDice() {
        roll();
    }

    public void roll() {
        die1 = (int)(Math.random() * 6) + 1;
        die2 = (int)(Math.random() * 6) + 1;
    }

    public int getDie1() {
        return die1;
    }

    public int getDie2() {
        return die2;
    }

    public int getTotal() {
        return die1 + die2;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Q12PairOfDice dice = new Q12PairOfDice();

        System.out.println("Dice Rolling Game (type 'exit' to quit)");

        while (true) {
            System.out.print("\nEnter target sum (2-12) or 'exit': ");
            String input = scanner.nextLine();

            if (input.equalsIgnoreCase("exit")) {
                break;
            }

            try {
                int target = Integer.parseInt(input);

                if (target < 2 || target > 12) {
                    System.out.println("Please enter a number between 2-12");
                    continue;
                }

                int rolls = 0;
                do {
                    dice.roll();
                    rolls++;
                    System.out.printf("Roll %d: %d + %d = %d%n",
                            rolls, dice.getDie1(), dice.getDie2(), dice.getTotal());
                } while (dice.getTotal() != target);

                System.out.println("Got " + target + " after " + rolls + " rolls!");

            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number or 'exit'");
            }
        }

        System.out.println("Thanks for playing!");
    }
}
