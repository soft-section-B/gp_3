package WORKSHEETOOP;
import java.util.Scanner;

public class Q14PrimeHappyChecker {


    public static boolean isPrime(int num) {
        if (num < 2) return false;
        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0) return false;
        }
        return true;
    }


    public static int isPrimeHappy(int n) {
        int sum = 0;
        boolean hasPrime = false;

        for (int i = 2; i < n; i++) {
            if (isPrime(i)) {
                sum += i;
                hasPrime = true;
            }
        }

        if (!hasPrime) {
            return 0;
        }

        if (sum % n == 0) {
            return 1;
        }

        return 0;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input;

        System.out.println("Check if a number is prime-happy (type 'exit' to quit):");

        while (true) {
            System.out.print("Enter number: ");
            input = scanner.nextLine();

            if (input.equalsIgnoreCase("exit")) {
                System.out.println("Goodbye!");
                break;
            }

            try {
                int number = Integer.parseInt(input);
                int result = isPrimeHappy(number);
                if (result == 1) {
                    System.out.println( " 1");
                } else {
                    System.out.println( "0");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid integer or type 'exit' to quit.");
            }
        }

        scanner.close();
    }
}
