package WORKSHEETOOP;
public class Q2MultiplesOfThree {
    public static void main(String[] args) {
        for (int i = 3; i <= 36; i += 3) {
            System.out.print(i + " ");
        }
    }
}