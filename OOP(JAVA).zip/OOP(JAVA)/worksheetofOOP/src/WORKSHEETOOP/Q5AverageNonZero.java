package WORKSHEETOOP;
import java.util.Scanner;

public class Q5AverageNonZero {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Non-Zero Average Calculator (Type 'exit' to quit)");

        while (true) {
            System.out.print("\nEnter array size (1-20) or 'exit': ");
            String input = scanner.nextLine();

            if (input.equalsIgnoreCase("exit")) {
                break;
            }

            try {
                int size = Integer.parseInt(input);

                if (size <= 0 || size > 20) {
                    System.out.println("Size must be between 1 and 20");
                    continue;
                }

                System.out.print("Enter " + size + " numbers separated by spaces: ");
                String numbersInput = scanner.nextLine();
                String[] numbersStr = numbersInput.split(" ");

                if (numbersStr.length != size) {
                    System.out.println("You must enter exactly " + size + " numbers");
                    continue;
                }

                double[] A = new double[size];
                for (int i = 0; i < size; i++) {
                    A[i] = Double.parseDouble(numbersStr[i]);
                }

                double sum = 0;
                int count = 0;
                for (double num : A) {
                    if (num != 0) {
                        sum += num;
                        count++;
                    }
                }

                if (count == 0) {
                    System.out.println("No non-zero numbers found");
                } else {
                    System.out.printf("Average of non-zero numbers: %.2f%n", sum / count);
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter numbers only");
            }
        }

        System.out.println("Program ended. Goodbye!");
    }
}